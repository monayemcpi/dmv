<?php $__env->startSection('content'); ?>

<div class="card mt-5">

  <div class="card-header bg-success text-white d-flex justify-content-between">
    <h4><i class="fa fa-plus"></i> Make Exam</h4>
    <a  class="btn btn-primary" href="<?php echo e(route('exams.index')); ?>"> <i class="fa fa-question"></i> All Exams</a>
  </div>



  <div class="card-body">

        <div class="row">
        <div class="col-md-12">
            <?php if(isset($answerStatus)): ?>

                <?php if($answerStatus == true): ?>
                    <div class="alert alert-success alert-dismissible fade show">
                        <button type="button" class="btn-close" data-dismiss="alert"
                            aria-hidden="true"></button>
                        <strong>Correct Answer</strong>
                    </div>
                <?php else: ?>
                    <div class="alert alert-danger alert-dismissible fade show">
                        <button type="button" class="btn-close" data-dismiss="alert"
                            aria-hidden="true"></button>
                        <strong>Warning!</strong> Wrong Answer
                    </div>
                <?php endif; ?>

            <?php endif; ?>
        </div>
    </div>

    <form action="<?php echo e(route('exams.store')); ?>" method="POST" id="questionForm">
      <input type="hidden" name="exam_record_id" value="<?php echo e($examRecordId); ?>" readonly class="form-control">
        <?php echo csrf_field(); ?>

        <h5 class="mb-2"><strong>Question:</strong></h5><hr>  
        <div class="form-group mb-3">
            <h5><?php echo e($question->question); ?>?</h4>
            <input required
                type="hidden"
                name="question_id"
                class="form-control"
                readonly
                value="<?php echo e($question->id); ?>"
                placeholder="Enter question">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="form-text text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
         <?php if($question -> image): ?> 
            <img src="<?php echo e(asset($question -> image)); ?>" alt="" style =" width: 100px; height: 100px " id = "imgPrev" >

            
     
            <?php endif; ?>

       <div class="options mb-3">
        <?php $i=0; ?>
          <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group mb-4">
            <div class="form-check radioHolder">
              <input class="form-check-input" type="radio" name="answer"  value="<?php echo e($i++); ?>">
              <h5 class="form-check-label">
                <?php echo e($option); ?>

              </h5>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <button type="submit" class="btn btn-success"><i class="fa-solid fa-floppy-disk"></i> Submit</button>

    </form>

  </div>
</div>

<style>
    .error{
        color:red;
    }
</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
//$("#questionForm").validate();

$(function(){


var options = $(".options");

options.html(options.find(".radioHolder").sort(function() {
  return (Math.random() - 0.5);
}));



})

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\dmv\resources\views/exams/create.blade.php ENDPATH**/ ?>