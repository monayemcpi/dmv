<?php $__env->startSection('content'); ?>

<div class="card mt-5">

  <div class="card-header bg-success text-white d-flex justify-content-between">
    <h4> <i class="fa-solid fa-user-graduate"></i> Exams</h4>
    <a  class="btn btn-primary" href="<?php echo e(route('exams.create')); ?>"> <i class="fa fa-plus"></i> Take a exam</a>
  </div>

  <div class="card-body">
        <table class="table table-bordered table-striped mt-4 data-table">
            <thead>
                <tr>
                    <th width="80px">Sl #</th>
                    <th>Exam date</th> 
                    <th>Exam time</th> 
                    <th width="250px">Action</th>
                </tr>
            </thead>

            <tbody>
                <?php $i=0; ?>
            <?php $__empty_1 = true; $__currentLoopData = $examRecord; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e(++$i); ?></td>
                    <td><?php echo e(date("m-d-Y", strtotime($exam->date))); ?></td>
                    <td><?php echo e(date('h:i:s a', strtotime($exam->time))); ?></td>
                    <td class="d-flex justify-content-between">
                        <a href="<?php echo e(route('exams.show',$exam->id)); ?>" class="btn btn-sm btn-success text-white"><i class="fa fa-eye"></i> View Result</a>
                        <form action="<?php echo e(route('exams.destroy',$exam->id)); ?>" method="POST">
                             <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i> Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4">There are no data.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>

$(document).ready( function () {
    $('.data-table').DataTable();
} );

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\dmv\resources\views/exams/index.blade.php ENDPATH**/ ?>