<?php $__env->startSection('content'); ?>

<div class="card mt-5">

  <div class="card-header bg-success text-white d-flex justify-content-between">
    <h4><i class="fa fa-edit"></i> Edit Question</h4>
    <a  class="btn btn-primary" href="<?php echo e(route('questions.index')); ?>"> <i class="fa fa-question"></i> All Questions</a>
  </div>

  <div class="card-body">

    <form action="<?php echo e(route('questions.update', $questions->id)); ?>" method="POST" enctype="multipart/form-data">
        
       <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group mb-3">
            <label class="mb-2"><strong>Question:</strong></label>
            <input
                type="text"
                name="question"
                value="<?php echo e($questions->question); ?>"
                class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                id="inputName"
                placeholder="Enter question">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="form-text text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
       
        
        <div class="form-group mb-3">
            <label class="mb-2"><strong>Upload Image:</strong></label>
            <?php if($questions -> image): ?> 
            <img src="<?php echo e(asset($questions -> image)); ?>" alt="" style =" width: 100px; height: 100px " id = "imgPrev" >

            <?php else: ?>
             <img src="" alt="" style =" width: 100px; height: 100px " id = "imgPrev" >

                
            <?php endif; ?>
              
            <input 
                type="file"
                accept="image/*" 
                name="image"
                class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                id="inputImg"
                placeholder="">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="form-text text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>

        <?php $i=1; $ck=1;?>
        <?php $__currentLoopData = $questions->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
        
        <div class="form-group mb-3">
            <label class="mb-2" ><strong>Option <?php echo e($i); ?>:</strong></label>
            <input
                type="text"
                name="options[]"
                value="<?php echo e($option); ?>"
                class="form-control <?php $__errorArgs = ['options'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                id="Option"
                placeholder="Enter Option <?php echo e($i++); ?>">
            <?php $__errorArgs = ['option'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="form-text text-danger"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




    <div class="form-group mb-3">
<label class="mb-2" ><strong>Answer:</strong></label>
    <select class="form-select" name="answer" aria-label="Default select example">
        <option value="">Select Answer</option>
        <?php for($i=0;$i<4;$i++): ?>
            <option <?php echo e($questions->answer == $i ? 'selected':''); ?> value="<?php echo e($i); ?>">Option <?php echo e($ck++); ?></option>
        <?php endfor; ?>
    </select>
    </div>


        <button type="submit" class="btn btn-success"><i class="fa-solid fa-floppy-disk"></i> Submit</button>

    </form>

  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script>
$("#questionForm").validate();
// Image Preview
inputImg.onchange = evt => {
const [file] = inputImg.files
// debugger;
  if (file) {
    imgPrev.src = URL.createObjectURL(file)
  }
}




</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\dmv\resources\views/questions/edit.blade.php ENDPATH**/ ?>