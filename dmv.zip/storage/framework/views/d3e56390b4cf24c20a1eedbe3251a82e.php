<?php $__env->startSection('content'); ?>
<div class="row">

    <div class="col-md-4">
        <div class="card border-primary mb-3 mt-3" style="max-width: 18rem;">
            <div class="card-header">Total Questions</div>
            <div class="card-body text-primary">
                <h5 class="card-title"><?php echo e($questions?$questions:'-'); ?></h5>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card border-primary mb-3 mt-3" style="max-width: 18rem;">
            <div class="card-header">No. of Exam</div>
            <div class="card-body text-primary">
                <h5 class="card-title"><?php echo e($exams?$exams:'-'); ?></h5>
            </div>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card border-primary mb-3 mt-3" style="max-width: 18rem;">
            <div class="card-header">Last Exam Taken</div>
            <div class="card-body text-primary">
                <h5 class="card-title"><?php echo e($lastExam ? date("m-d-Y", strtotime($lastExam->date)):'-'); ?></h5>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\dmv\resources\views/home/index.blade.php ENDPATH**/ ?>