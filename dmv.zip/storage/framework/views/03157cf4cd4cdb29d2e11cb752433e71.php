<?php $__env->startSection('content'); ?>

<div class="card mt-5">

  <div class="card-header bg-success text-white d-flex justify-content-between">
    <h4><i class="fa fa-eye"></i> Show Question</h4>
    <a  class="btn btn-primary" href="<?php echo e(route('questions.index')); ?>"> <i class="fa fa-question"></i> All Questions</a>
  </div>

  <div class="card-body">

    <div class="form-group mb-3">
        <label class="mb-2">Question</label>
        <input type="text" class="form-control" value="<?php echo e($questions->question); ?>" readonly>
    </div>

     <div class="form-group mb-3">
        <label class="mb-2">Image</label>
        <img src="<?php echo e(asset($questions->image)); ?>" alt="" style="width: 150px; height: 150px; object-fit: contain;">
    </div>
    <?php $i=1 ?>
    <?php $__currentLoopData = $questions->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-group mb-3">
        <label class="mb-2">Option <?php echo e($i++); ?></label>
        <input type="text" class="form-control" value="<?php echo e($option); ?>" readonly>
    </div>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="form-group">
      <label for="">Answer : </label>
      <?php if(array_key_exists($questions->answer, $questions->options)): ?>

      <span class="badge rounded-pill bg-success">Option <?php echo e($questions->answer+1); ?> </span>
      <span><?php echo e($questions->options[$questions->answer]); ?></span>

      <?php else: ?>

      <span>No Answer</span>
        
      <?php endif; ?>
      
    </div>

  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\dmv\resources\views/questions/show.blade.php ENDPATH**/ ?>