<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>DMV</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.datatables.net/2.3.4/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('/public/css/all.min.css')); ?>">
  </head>
  <body>
    
<header>
    <nav class="navbar navbar-light navbar-expand-lg bg-success text-white" >
      <div class="container">
        <a class="navbar-brand text-white" href="<?php echo e(url('/')); ?>"> <i class="fa-solid fa-car"></i> DMV</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link text-white" href="<?php echo e(url('/')); ?>">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href="<?php echo e(route('questions.index')); ?>">Questions</a>
            </li>
            <li class="nav-item">
              <a class="nav-link text-white" href="<?php echo e(route('exams.index')); ?>">Exams</a>
            </li>
          </ul>
        </div>

      </div>
    </nav>
</header>

<main>
  <div class="container">
    <div class="row">
        <div class="col-md-12">

          <div class="mt-3">

              <!--  Alert -->
              <div class="row">
                  <div class="col-md-12">
                      <?php if(Session::has('success')): ?>
                      <div class="alert alert-success alert-dismissible fade show">
                          <button type="button" class="btn-close" data-dismiss="alert"
                              aria-hidden="true"></button>
                          <strong>Success!</strong> <?php echo e(Session::get('success')); ?>

                      </div>
                      <?php endif; ?> <?php if(Session::has('danger')): ?>
                      <div class="alert alert-danger alert-dismissible fade show">
                          <button type="button" class="btn-close" data-dismiss="alert"
                              aria-hidden="true"></button>
                          <strong>Warning!</strong> <?php echo e(Session::get('danger')); ?>

                      </div>
                      <?php endif; ?> <?php if(count($errors) > 0): ?>
                      <div class="alert alert-danger alert-dismissible fade show">
                          <button type="button" class="btn-close" data-dismiss="alert"
                              aria-hidden="true"></button>
                          <strong>Whoops!</strong> There were some problems with your input.
                          <br>
                          <br>
                          <ul>
                              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><?php echo e($error); ?></li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </ul>
                      </div>
                      <?php endif; ?>
                  </div>
              </div>
              <!-- /Alert -->

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

          </div>


          <?php echo $__env->yieldContent('content'); ?>

        </div>
    </div>
</div>
</main>

    <script type="text/javascript" src="<?php echo e(asset('/public/js/jquery-3.4.1.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('/public/js/jquery.validate.min.js')); ?>"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/2.3.4/js/dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/2.3.4/js/dataTables.bootstrap5.min.js"></script>
    <?php echo $__env->yieldContent('script'); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
  </body>
</html><?php /**PATH C:\laragon\www\dmv\resources\views/app.blade.php ENDPATH**/ ?>