<?php $__env->startSection('content'); ?>

<div class="card mt-5">

  <div class="card-header bg-success text-white d-flex justify-content-between">
    <h4> <i class="fa fa-question"></i> Questions</h4>
    <a  class="btn btn-primary" href="<?php echo e(route('questions.create')); ?>"> <i class="fa fa-plus"></i> Create New Question</a>
  </div>

  <div class="card-body">
        <table class="table table-bordered table-striped mt-4 data-table">
            <thead>
                <tr>
                    <th width="80px">Sl #</th>
                    <th>Question</th>
                    <th width="250px">Action</th>
                </tr>
            </thead>

            <tbody>
                <?php $i=0; ?>
            <?php $__empty_1 = true; $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e(++$i); ?></td>
                    <td><?php echo e($question->question); ?></td>
                    <td class="d-flex justify-content-between">
                        <a href="<?php echo e(route('questions.edit',$question->id)); ?>" class="btn btn-sm btn-primary"><i class="fa fa-pencil"></i> Edit</a>
                        <a href="<?php echo e(route('questions.show',$question->id)); ?>" class="btn btn-sm btn-success text-white"><i class="fa fa-eye"></i> View</a>
                        <form action="<?php echo e(route('questions.destroy',$question->id)); ?>" method="POST">
                             <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i> Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4">There are no data.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<script>

$(document).ready( function () {
    $('.data-table').DataTable();
} );

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\dmv\resources\views/questions/index.blade.php ENDPATH**/ ?>