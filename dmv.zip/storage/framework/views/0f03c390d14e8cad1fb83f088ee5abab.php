

<?php $__env->startSection('content'); ?>

<div class="card mt-5">

  <div class="card-header bg-success text-white d-flex justify-content-between">
    <h4> <i class="fa-solid fa-user-graduate"></i> Result</h4>
    <a  class="btn btn-primary" href="<?php echo e(route('exams.index')); ?>"> <i class="fa fa-plus"></i>All Exams</a>
  </div>

  <div class="card-body">
        <table class="table table-bordered table-striped mt-4 data-table">
            <thead>
                <tr>
                    <th width="80px">Sl #</th>
                    <th>Question</th>
                    <th>Answer</th>
                </tr>
            </thead>

            <tbody>
                <?php $i=0; ?>
            <?php $__empty_1 = true; $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e(++$i); ?></td>
                    <td><?php echo e($row->question); ?></td>
                    <td>
                        <?php echo $row->status == 1 ?'<i class="fa-solid fa-check text-success"></i>':'<i class="fa-solid fa-x text-danger"></i>'; ?>

                        
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4">There are no data.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
  </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<script>

$(document).ready( function () {
    $('.data-table').DataTable();
} );

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\dmv\resources\views/exams/show.blade.php ENDPATH**/ ?>